package com.adobe.cq;

import java.io.IOException;
import java.rmi.ServerException;
import java.util.HashMap;
import java.util.Map;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@SlingServlet(paths="/bin/firstServlet", methods = "POST", metatype=false)
public class ServletAjax extends SlingAllMethodsServlet {
	 private static final long serialVersionUID= 2598426539166789515L;
	 private static final Logger LOG = LoggerFactory.getLogger(ServletAjax.class);
	 @Reference
	 public ResourceResolverFactory rrFactory;
	 ResourceResolver resourceResolver = null;

	

	 
	 @Override
     protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
		 Map param1 = new HashMap();
		   try
		  	{
		  		param1.put(ResourceResolverFactory.SUBSERVICE, "myadminservice");
		  		resourceResolver = rrFactory.getServiceResourceResolver(param1);
		  		LOG.info("Resource Resolver is"+resourceResolver.getUserID());
		  		//adminResolver = rrFactory.getAdministrativeResourceResolver(null);
		  	}catch(LoginException ex)
		  	{
		  		LOG.error("LoginException."+ ex.getMessage()+ex);
		  	}
		   try
		      {
		 String firstName = request.getParameter("firstName");
         String lastName = request.getParameter("lastName");
         String address = request.getParameter("address");
         
         JSONObject obj=new JSONObject();
         obj.put("firstname",firstName);
         obj.put("lastname",lastName);
         obj.put("address",address);
         
         String jsonData = obj.toString();
         LOG.info("Response is"+jsonData);
         
         response.getWriter().write(jsonData);
	 }
	 catch(Exception e){
		 LOG.info("Error is "+e.getMessage());
	 }

}
}
