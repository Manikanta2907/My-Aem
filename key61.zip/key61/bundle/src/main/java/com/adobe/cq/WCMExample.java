package com.adobe.cq;



import javax.jcr.Node;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class WCMExample extends WCMUsePojo{
	private static final Logger log = LoggerFactory.getLogger(WCMExample.class);
	
	private HeroTextBean heroTextBean = null;
	 @Override
	    public void activate() throws Exception {
		 
		 Node currentNode = getResource().adaptTo(Node.class);
		 log.info("Current Node is"+currentNode.getName());
		 heroTextBean = new HeroTextBean();
		 if(currentNode.hasProperty("headingtext")){
	            heroTextBean.setHeadingText(currentNode.getProperty("./headingtext").getString());
	        }
		 if(currentNode.hasProperty("description")){
	            heroTextBean.setDescription(currentNode.getProperty("./description").getString());
	        }
	 }
	 public HeroTextBean getHeroTextBean() {
	        return this.heroTextBean;
	    }
}
