package com.adobe.cq;

public interface SampleService {
	
	 public String helloWorld();

}
