package com.adobe.cq;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SlingServlet(resourceTypes="geometrix/components/homepage",selectors="data",extensions="html",methods="GET",metatype=false)
public class ResourceTypeServlet extends SlingSafeMethodsServlet{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(ResourceTypeServlet.class);
	 @Reference
	 public ResourceResolverFactory rrFactory;
	 ResourceResolver resourceResolver = null;
	 protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException{
		 Map param1 = new HashMap();
		   try
		  	{
		  		param1.put(ResourceResolverFactory.SUBSERVICE, "myadminservice");
		  		resourceResolver = rrFactory.getServiceResourceResolver(param1);
		  		LOG.info("Resource Resolver is"+resourceResolver.getUserID());
		  		//adminResolver = rrFactory.getAdministrativeResourceResolver(null);
		  	}catch(LoginException ex)
		  	{
		  		LOG.error("LoginException."+ ex.getMessage()+ex);
		  	}   
		 response.setHeader("Content-Type", "application/json");
			response.getWriter().print("{\"coming\" : \"soon\"}");
	 }

}
