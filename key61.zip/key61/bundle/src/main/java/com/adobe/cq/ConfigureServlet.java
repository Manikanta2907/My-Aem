package com.adobe.cq;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Modified;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Component(immediate=true,metatype=true,description="Sample Configuration Servlet")
@Service(Servlet.class)
@Properties(value={
		@Property(name="sling.servlet.paths",value="/bin/configureServlet"),
		@Property(name="sling.servlet.methods",value="GET"),
		@Property(name="sampletext", label="Enter Some Text", description="Sample Servlet Example", value="Hai")
		
})
public class ConfigureServlet extends SlingSafeMethodsServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 private static final Logger LOG = LoggerFactory.getLogger(ConfigureServlet.class);
	private String sampletext;
	 @Reference
	 public ResourceResolverFactory rrFactory;
	 ResourceResolver resourceResolver = null;
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		 Map param1 = new HashMap();
		   try
		  	{
		  		param1.put(ResourceResolverFactory.SUBSERVICE, "myadminservice");
		  		resourceResolver = rrFactory.getServiceResourceResolver(param1);
		  		LOG.info("Resource Resolver is"+resourceResolver.getUserID());
		  		//adminResolver = rrFactory.getAdministrativeResourceResolver(null);
		  	}catch(LoginException ex)
		  	{
		  		LOG.error("LoginException."+ ex.getMessage()+ex);
		  	}
		response.getWriter().print(this.sampletext);
	}
	@Activate
	protected void activate(Map < String, Object > properties) {
		this.sampletext = PropertiesUtil.toString(properties.get("sampletext"), "");
		
	}
	@Modified
	protected void modified(ComponentContext context){
		this.sampletext = PropertiesUtil.toString(context.getProperties().get("sampletext"), "");
	}

}
