package com.adobe.cq.impl;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;

import com.adobe.cq.SampleService;
@Component(metatype = false)
@Service
public class SampleServiceImpl implements SampleService{

	
	public String helloWorld(){
		return "Hello World";
	}
}
