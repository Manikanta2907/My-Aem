function getNameFirst() {
    // return the name
    return "some value";
}